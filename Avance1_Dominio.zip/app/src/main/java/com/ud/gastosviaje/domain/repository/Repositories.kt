package com.ud.gastosviaje.domain.repository

import com.ud.gastosviaje.domain.model.Category
import com.ud.gastosviaje.domain.model.Expense
import com.ud.gastosviaje.domain.model.NewExpense
import com.ud.gastosviaje.domain.model.NewTrip
import com.ud.gastosviaje.domain.model.Trip

interface TripRepository {
    suspend fun getTrips(): List<Trip>
    suspend fun getTrip(tripId: String): Trip
    suspend fun createTrip(newTrip: NewTrip): Trip
}

interface ExpenseRepository {
    suspend fun getExpenses(tripId: String): List<Expense>
    suspend fun registerExpense(newExpense: NewExpense): Expense
    suspend fun getCategories(): List<Category>
}
