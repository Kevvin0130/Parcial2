package com.ud.gastosviaje.domain.model

import com.ud.gastosviaje.domain.validation.ValidationError

sealed interface SaveResult<out T> {
    data class Success<T>(val value: T) : SaveResult<T>
    data class Invalid(val errors: Set<ValidationError>) : SaveResult<Nothing>
    data class Failure(val message: String?) : SaveResult<Nothing>
}
