package com.ud.gastosviaje.domain

import com.ud.gastosviaje.domain.model.TripForm
import com.ud.gastosviaje.domain.validation.TripValidator
import com.ud.gastosviaje.domain.validation.ValidationError
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class TripValidatorTest {

    private val validator = TripValidator()
    private val valid = TripForm(
        name = "Europa 2026",
        destination = "Italia",
        startDate = LocalDate.of(2026, 6, 10),
        endDate = LocalDate.of(2026, 6, 20)
    )

    @Test
    fun `formulario completo no tiene errores`() {
        assertTrue(validator.validate(valid).isEmpty())
    }

    @Test
    fun `formulario vacio reporta todos los campos obligatorios`() {
        assertEquals(
            setOf(
                ValidationError.NAME_REQUIRED,
                ValidationError.DESTINATION_REQUIRED,
                ValidationError.START_DATE_REQUIRED,
                ValidationError.END_DATE_REQUIRED
            ),
            validator.validate(TripForm())
        )
    }

    @Test
    fun `nombre con solo espacios es invalido`() {
        assertEquals(setOf(ValidationError.NAME_REQUIRED), validator.validate(valid.copy(name = "   ")))
    }

    @Test
    fun `fecha de fin anterior al inicio es invalida`() {
        val form = valid.copy(endDate = LocalDate.of(2026, 6, 9))
        assertEquals(setOf(ValidationError.END_BEFORE_START), validator.validate(form))
    }

    @Test
    fun `viaje de un solo dia es valido`() {
        val form = valid.copy(endDate = valid.startDate)
        assertTrue(validator.validate(form).isEmpty())
    }
}
