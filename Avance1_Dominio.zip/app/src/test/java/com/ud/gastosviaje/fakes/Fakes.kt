package com.ud.gastosviaje.fakes

import com.ud.gastosviaje.domain.model.Category
import com.ud.gastosviaje.domain.model.Expense
import com.ud.gastosviaje.domain.model.NewExpense
import com.ud.gastosviaje.domain.model.NewTrip
import com.ud.gastosviaje.domain.model.Trip
import com.ud.gastosviaje.domain.repository.ExpenseRepository
import com.ud.gastosviaje.domain.repository.TripRepository
import java.math.BigDecimal
import java.time.LocalDate

object TestData {
    val food = Category("1", "Alimentación")
    val lodging = Category("2", "Alojamiento")
    val transport = Category("3", "Transporte")
    val categories = listOf(food, lodging, transport)

    val europe = Trip("t1", "Europa 2026", "Italia", LocalDate.of(2026, 6, 10), LocalDate.of(2026, 6, 20))
    val santaMarta = Trip("t2", "Santa Marta", "Colombia", LocalDate.of(2026, 7, 1), LocalDate.of(2026, 7, 6))

    fun expense(id: String, amount: String, date: LocalDate, category: Category = food, tripId: String = "t1") =
        Expense(id, tripId, "Gasto $id", BigDecimal(amount), category, date)
}

class FakeTripRepository(
    trips: List<Trip> = listOf(TestData.europe, TestData.santaMarta)
) : TripRepository {
    val trips = trips.toMutableList()
    var shouldFail = false
    var created: NewTrip? = null

    override suspend fun getTrips(): List<Trip> {
        if (shouldFail) error("Sin conexión")
        return trips.toList()
    }

    override suspend fun getTrip(tripId: String): Trip {
        if (shouldFail) error("Sin conexión")
        return trips.first { it.id == tripId }
    }

    override suspend fun createTrip(newTrip: NewTrip): Trip {
        if (shouldFail) error("Sin conexión")
        created = newTrip
        val trip = Trip("new", newTrip.name, newTrip.destination, newTrip.startDate, newTrip.endDate, newTrip.notes)
        trips += trip
        return trip
    }
}

class FakeExpenseRepository(expenses: List<Expense> = emptyList()) : ExpenseRepository {
    val expenses = expenses.toMutableList()
    var shouldFail = false
    var registered: NewExpense? = null

    override suspend fun getExpenses(tripId: String): List<Expense> {
        if (shouldFail) error("Sin conexión")
        return expenses.filter { it.tripId == tripId }
    }

    override suspend fun registerExpense(newExpense: NewExpense): Expense {
        if (shouldFail) error("Sin conexión")
        registered = newExpense
        val expense = Expense(
            "e${expenses.size + 1}", newExpense.tripId, newExpense.description,
            newExpense.amount, newExpense.category, newExpense.date
        )
        expenses += expense
        return expense
    }

    override suspend fun getCategories(): List<Category> {
        if (shouldFail) error("Sin conexión")
        return TestData.categories
    }
}
