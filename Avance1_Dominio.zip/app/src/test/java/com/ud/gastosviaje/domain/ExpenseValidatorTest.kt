package com.ud.gastosviaje.domain

import com.ud.gastosviaje.domain.model.ExpenseForm
import com.ud.gastosviaje.domain.validation.ExpenseValidator
import com.ud.gastosviaje.domain.validation.ValidationError
import com.ud.gastosviaje.fakes.TestData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class ExpenseValidatorTest {

    private val validator = ExpenseValidator()
    private val trip = TestData.europe
    private val valid = ExpenseForm(
        description = "Cena en Trastevere",
        amount = "28.50",
        category = TestData.food,
        date = LocalDate.of(2026, 6, 12)
    )

    @Test
    fun `gasto valido no tiene errores`() {
        assertTrue(validator.validate(valid, trip).isEmpty())
    }

    @Test
    fun `formulario vacio reporta campos obligatorios`() {
        assertEquals(
            setOf(
                ValidationError.DESCRIPTION_REQUIRED,
                ValidationError.AMOUNT_REQUIRED,
                ValidationError.CATEGORY_REQUIRED,
                ValidationError.DATE_REQUIRED
            ),
            validator.validate(ExpenseForm(), trip)
        )
    }

    @Test
    fun `valor cero o negativo no es positivo`() {
        assertEquals(setOf(ValidationError.AMOUNT_NOT_POSITIVE), validator.validate(valid.copy(amount = "0"), trip))
        assertEquals(setOf(ValidationError.AMOUNT_NOT_POSITIVE), validator.validate(valid.copy(amount = "-5"), trip))
    }

    @Test
    fun `valor no numerico es invalido`() {
        assertEquals(setOf(ValidationError.AMOUNT_INVALID), validator.validate(valid.copy(amount = "abc"), trip))
    }

    @Test
    fun `acepta coma como separador decimal`() {
        assertEquals(BigDecimal("28.50"), ExpenseValidator.parseAmount("28,50"))
        assertNull(ExpenseValidator.parseAmount("doce"))
    }

    @Test
    fun `fecha antes o despues del viaje es invalida`() {
        val before = valid.copy(date = LocalDate.of(2026, 6, 9))
        val after = valid.copy(date = LocalDate.of(2026, 6, 21))
        assertEquals(setOf(ValidationError.DATE_OUT_OF_TRIP_RANGE), validator.validate(before, trip))
        assertEquals(setOf(ValidationError.DATE_OUT_OF_TRIP_RANGE), validator.validate(after, trip))
    }

    @Test
    fun `fechas limite del viaje son validas`() {
        assertTrue(validator.validate(valid.copy(date = trip.startDate), trip).isEmpty())
        assertTrue(validator.validate(valid.copy(date = trip.endDate), trip).isEmpty())
    }
}
