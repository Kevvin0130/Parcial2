package com.ud.gastosviaje.domain

import com.ud.gastosviaje.domain.model.ExpenseForm
import com.ud.gastosviaje.domain.model.SaveResult
import com.ud.gastosviaje.domain.model.TripForm
import com.ud.gastosviaje.domain.usecase.CalculateTotalExpensesUseCase
import com.ud.gastosviaje.domain.usecase.CreateTripUseCase
import com.ud.gastosviaje.domain.usecase.GetCategoriesUseCase
import com.ud.gastosviaje.domain.usecase.GetExpensesUseCase
import com.ud.gastosviaje.domain.usecase.GetTripDetailUseCase
import com.ud.gastosviaje.domain.usecase.GetTripsUseCase
import com.ud.gastosviaje.domain.usecase.RegisterExpenseUseCase
import com.ud.gastosviaje.domain.validation.ExpenseValidator
import com.ud.gastosviaje.domain.validation.TripValidator
import com.ud.gastosviaje.domain.validation.ValidationError
import com.ud.gastosviaje.fakes.FakeExpenseRepository
import com.ud.gastosviaje.fakes.FakeTripRepository
import com.ud.gastosviaje.fakes.TestData
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class UseCasesTest {

    private val tripRepo = FakeTripRepository()
    private val expenseRepo = FakeExpenseRepository(
        listOf(
            TestData.expense("e1", "28.50", LocalDate.of(2026, 6, 12)),
            TestData.expense("e2", "260.00", LocalDate.of(2026, 6, 10), TestData.lodging),
            TestData.expense("e3", "7.00", LocalDate.of(2026, 6, 13), TestData.transport),
            TestData.expense("x1", "99.00", LocalDate.of(2026, 7, 2), tripId = "t2")
        )
    )
    private val getExpenses = GetExpensesUseCase(expenseRepo)
    private val calculateTotal = CalculateTotalExpensesUseCase()

    // Req. 1
    @Test
    fun `consultar viajes devuelve nombre y destino`() = runTest {
        val trips = GetTripsUseCase(tripRepo)()
        assertEquals(listOf("Europa 2026" to "Italia", "Santa Marta" to "Colombia"), trips.map { it.name to it.destination })
    }

    // Req. 2
    @Test
    fun `crear viaje valido lo guarda con campos recortados`() = runTest {
        val form = TripForm("  Bogotá Cultural ", " Colombia ", LocalDate.of(2026, 8, 14), LocalDate.of(2026, 8, 17))
        val result = CreateTripUseCase(tripRepo, TripValidator())(form)
        assertTrue(result is SaveResult.Success)
        assertEquals("Bogotá Cultural", tripRepo.created?.name)
        assertEquals("Colombia", tripRepo.created?.destination)
    }

    @Test
    fun `crear viaje invalido no llama al repositorio`() = runTest {
        val result = CreateTripUseCase(tripRepo, TripValidator())(TripForm())
        assertTrue(result is SaveResult.Invalid)
        assertNull(tripRepo.created)
    }

    @Test
    fun `crear viaje con error del backend devuelve Failure`() = runTest {
        tripRepo.shouldFail = true
        val form = TripForm("A", "B", LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 2))
        val result = CreateTripUseCase(tripRepo, TripValidator())(form)
        assertEquals(SaveResult.Failure("Sin conexión"), result)
    }

    // Req. 3, 4 y 7
    @Test
    fun `detalle incluye solo gastos del viaje y su total`() = runTest {
        val detail = GetTripDetailUseCase(tripRepo, getExpenses, calculateTotal)("t1")
        assertEquals("Europa 2026", detail.trip.name)
        assertEquals(3, detail.expenses.size)
        assertEquals(0, BigDecimal("295.50").compareTo(detail.total))
    }

    @Test
    fun `gastos se ordenan del mas reciente al mas antiguo`() = runTest {
        val dates = getExpenses("t1").map { it.date.dayOfMonth }
        assertEquals(listOf(13, 12, 10), dates)
    }

    @Test
    fun `total de lista vacia es cero`() {
        assertEquals(BigDecimal.ZERO, calculateTotal(emptyList()))
    }

    // Req. 5 y 8
    @Test
    fun `registrar gasto valido lo guarda`() = runTest {
        val form = ExpenseForm("Cena", "28,50", TestData.food, LocalDate.of(2026, 6, 12))
        val result = RegisterExpenseUseCase(tripRepo, expenseRepo, ExpenseValidator())("t1", form)
        assertTrue(result is SaveResult.Success)
        assertEquals(BigDecimal("28.50"), expenseRepo.registered?.amount)
    }

    @Test
    fun `registrar gasto fuera del periodo es rechazado`() = runTest {
        val form = ExpenseForm("Cena", "10", TestData.food, LocalDate.of(2026, 7, 1))
        val result = RegisterExpenseUseCase(tripRepo, expenseRepo, ExpenseValidator())("t1", form)
        assertEquals(SaveResult.Invalid(setOf(ValidationError.DATE_OUT_OF_TRIP_RANGE)), result)
        assertNull(expenseRepo.registered)
    }

    // Req. 6
    @Test
    fun `consultar categorias devuelve las disponibles`() = runTest {
        assertEquals(TestData.categories, GetCategoriesUseCase(expenseRepo)())
    }
}
